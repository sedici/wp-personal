<?php

namespace Personal\Inc\Core;

/**
 *
 * 
 *
 *  @author  SEDICI - Ezequiel Manzur - Maria Marta Vila
 */

class Deactivator {

	public static function deactivate() {
		
	}

}
